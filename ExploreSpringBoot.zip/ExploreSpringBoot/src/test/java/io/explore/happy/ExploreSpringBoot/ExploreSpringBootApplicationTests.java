package io.explore.happy.ExploreSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExploreSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
